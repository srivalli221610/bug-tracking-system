const bugList = document.getElementById("bugList");
const modal = document.getElementById("bugModal");
const form = document.getElementById("bugForm");
const filter = document.getElementById("statusFilter");
const toast = document.getElementById("toast");
let bugs = [];

function showToast(message) {
  toast.textContent = message;
  toast.classList.add("show");
  setTimeout(() => toast.classList.remove("show"), 2600);
}
function escapeHTML(value) {
  return String(value ?? "").replace(/[&<>"']/g, ch => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[ch]);
}
async function api(url, options = {}) {
  const response = await fetch(url, {
    headers: {"Content-Type": "application/json"},
    ...options
  });
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function render() {
  document.getElementById("totalCount").textContent = bugs.length;
  document.getElementById("openCount").textContent = bugs.filter(b => b.status === "Open").length;
  document.getElementById("progressCount").textContent = bugs.filter(b => b.status === "In Progress").length;
  document.getElementById("resolvedCount").textContent = bugs.filter(b => b.status === "Resolved").length;
  document.getElementById("criticalCount").innerHTML =
    `${bugs.filter(b => b.priority === "Critical").length} <span>critical issues</span>`;
  document.getElementById("openInsight").textContent =
    `${bugs.filter(b => b.status === "Open").length} open issues need attention.`;

  const visible = bugs.filter(b => filter.value === "All" || b.status === filter.value);
  if (!visible.length) {
    bugList.innerHTML = '<div class="empty">No bug reports here yet. Click “Report a bug” to create one.</div>';
    return;
  }
  bugList.innerHTML = visible.map(b => `
    <article class="bug-row">
      <div class="bug-main">
        <div class="bug-symbol">🐞</div>
        <div class="bug-copy">
          <div class="bug-title">#${b.id} · ${escapeHTML(b.title)}</div>
          <div class="bug-desc">${escapeHTML(b.description)}</div>
          <div class="bug-meta">
            <span class="tag priority-${escapeHTML(b.priority)}">${escapeHTML(b.priority)} priority</span>
            <span class="tag status-${b.status.replace(/\s/g, "-")}">${escapeHTML(b.status)}</span>
            <span class="tag">By ${escapeHTML(b.reporter)}</span>
            <span class="tag">${escapeHTML(b.created_at)}</span>
          </div>
        </div>
      </div>
      <div class="bug-actions">
        <select aria-label="Update status for bug ${b.id}" data-status-id="${b.id}">
          ${["Open","In Progress","Resolved"].map(s => `<option ${b.status===s?"selected":""}>${s}</option>`).join("")}
        </select>
        <button class="text-button" data-analysis-id="${b.id}">✦ AI analysis</button>
        <button class="text-button delete-button" data-delete-id="${b.id}">Delete</button>
      </div>
      <div class="analysis-box" id="analysis-${b.id}">${escapeHTML(b.ai_analysis || "No analysis available.")}</div>
    </article>
  `).join("");
}
async function loadBugs() {
  try { bugs = await api("/api/bugs"); render(); }
  catch (error) { bugList.innerHTML = `<div class="empty">${escapeHTML(error.message)}</div>`; }
}
function openModal() { modal.classList.remove("hidden"); document.getElementById("title").focus(); }
function closeModal() { modal.classList.add("hidden"); }
document.getElementById("openFormBtn").addEventListener("click", openModal);
document.getElementById("closeModalBtn").addEventListener("click", closeModal);
document.getElementById("cancelBtn").addEventListener("click", closeModal);
modal.addEventListener("click", event => { if (event.target === modal) closeModal(); });
filter.addEventListener("change", render);

form.addEventListener("submit", async event => {
  event.preventDefault();
  const submit = document.getElementById("submitBtn");
  const errorBox = document.getElementById("formError");
  submit.disabled = true;
  submit.textContent = "Analyzing…";
  errorBox.textContent = "";
  const payload = {
    title: form.title.value.trim(),
    description: form.description.value.trim(),
    reporter: form.reporter.value.trim(),
    priority: form.priority.value
  };
  try {
    await api("/api/bugs", {method:"POST", body:JSON.stringify(payload)});
    form.reset();
    closeModal();
    await loadBugs();
    showToast("Bug report saved and analyzed.");
  } catch (error) {
    errorBox.textContent = error.message;
  } finally {
    submit.disabled = false;
    submit.textContent = "✦ Submit & analyze";
  }
});

bugList.addEventListener("change", async event => {
  const id = event.target.dataset.statusId;
  if (!id) return;
  try {
    await api(`/api/bugs/${id}`, {method:"PATCH", body:JSON.stringify({status:event.target.value})});
    await loadBugs();
    showToast("Bug status updated.");
  } catch (error) { showToast(error.message); }
});
bugList.addEventListener("click", async event => {
  const analysisId = event.target.dataset.analysisId;
  const deleteId = event.target.dataset.deleteId;
  if (analysisId) {
    const button = event.target;
    button.disabled = true;
    button.textContent = "Analyzing…";
    try {
      const result = await api(`/api/bugs/${analysisId}/analyze`, {method:"POST", body:"{}"});
      document.getElementById(`analysis-${analysisId}`).textContent = result.analysis;
      const bug = bugs.find(item => item.id === Number(analysisId));
      if (bug) bug.ai_analysis = result.analysis;
      showToast("AI analysis refreshed.");
    } catch (error) { showToast(error.message); }
    finally { button.disabled = false; button.textContent = "✦ AI analysis"; }
  }
  if (deleteId) {
    if (!confirm(`Delete bug #${deleteId}? This cannot be undone.`)) return;
    try {
      await api(`/api/bugs/${deleteId}`, {method:"DELETE"});
      await loadBugs();
      showToast("Bug report deleted.");
    } catch (error) { showToast(error.message); }
  }
});
loadBugs();
