import os
import sqlite3
from datetime import datetime
from flask import Flask, render_template, request, jsonify, g

app = Flask(__name__)
DATABASE = os.path.join(os.path.dirname(__file__), "bugs.db")
VALID_PRIORITIES = {"Low", "Medium", "High", "Critical"}
VALID_STATUSES = {"Open", "In Progress", "Resolved"}

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DATABASE)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(error=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    with sqlite3.connect(DATABASE) as db:
        db.execute("""
            CREATE TABLE IF NOT EXISTS bugs (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                reporter TEXT NOT NULL,
                priority TEXT NOT NULL DEFAULT 'Medium',
                status TEXT NOT NULL DEFAULT 'Open',
                ai_analysis TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
        """)

def analyze_bug(title, description):
    """Use OpenAI if OPENAI_API_KEY is configured; otherwise use a simple offline helper."""
    text = f"Title: {title}\nDescription: {description}"
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key:
        try:
            from openai import OpenAI
            client = OpenAI(api_key=api_key)
            response = client.responses.create(
                model=os.getenv("OPENAI_MODEL", "gpt-5.5"),
                instructions=(
                    "You are a careful software QA assistant. Analyze bug reports. "
                    "Give: 1) likely cause (clearly label it as a hypothesis), "
                    "2) steps to investigate, 3) useful information the reporter should add. "
                    "Do not claim you ran the code or know the exact cause. Keep it concise."
                ),
                input=text
            )
            return response.output_text
        except Exception:
            # Keep the tracker usable if the AI service is unavailable.
            pass

    lower = text.lower()
    hints = []
    if any(word in lower for word in ("login", "sign in", "password", "authentication")):
        hints.append("Check authentication logic, credential validation, session/cookie handling, and server logs.")
    if any(word in lower for word in ("slow", "timeout", "loading", "hang")):
        hints.append("Check network requests, API response times, database queries, and browser console errors.")
    if any(word in lower for word in ("crash", "exception", "error", "failed", "failure")):
        hints.append("Capture the exact error message and stack trace; reproduce the issue with the same steps and inputs.")
    if any(word in lower for word in ("display", "layout", "button", "css", "screen")):
        hints.append("Inspect browser console errors, responsive layout rules, and whether the expected element is present.")
    if not hints:
        hints.append("Reproduce the issue, compare expected and actual behavior, and inspect application logs and browser console.")

    return (
        "AI analysis (basic rule-based fallback; configure OPENAI_API_KEY for model-powered analysis)\n\n"
        "Likely cause: This cannot be determined from the report alone; treat the following as investigation hypotheses.\n\n"
        "Suggested investigation:\n- " + "\n- ".join(hints) +
        "\n\nAdd to the report: exact reproduction steps, expected result, actual result, browser/device, "
        "timestamp, and any error messages."
    )

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/bugs")
def list_bugs():
    rows = get_db().execute("SELECT * FROM bugs ORDER BY id DESC").fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/bugs")
def create_bug():
    data = request.get_json(silent=True) or {}
    title = str(data.get("title", "")).strip()
    description = str(data.get("description", "")).strip()
    reporter = str(data.get("reporter", "")).strip()
    priority = str(data.get("priority", "Medium")).strip()
    if not title or not description or not reporter:
        return jsonify({"error": "Title, description, and reporter are required."}), 400
    if priority not in VALID_PRIORITIES:
        return jsonify({"error": "Invalid priority."}), 400

    analysis = analyze_bug(title, description)
    db = get_db()
    cursor = db.execute(
        "INSERT INTO bugs (title, description, reporter, priority, status, ai_analysis, created_at) "
        "VALUES (?, ?, ?, ?, 'Open', ?, ?)",
        (title, description, reporter, priority, analysis, datetime.now().strftime("%Y-%m-%d %H:%M"))
    )
    db.commit()
    row = db.execute("SELECT * FROM bugs WHERE id = ?", (cursor.lastrowid,)).fetchone()
    return jsonify(dict(row)), 201

@app.patch("/api/bugs/<int:bug_id>")
def update_bug(bug_id):
    data = request.get_json(silent=True) or {}
    status = data.get("status")
    if status not in VALID_STATUSES:
        return jsonify({"error": "Invalid status."}), 400
    db = get_db()
    cursor = db.execute("UPDATE bugs SET status = ? WHERE id = ?", (status, bug_id))
    db.commit()
    if cursor.rowcount == 0:
        return jsonify({"error": "Bug not found."}), 404
    row = db.execute("SELECT * FROM bugs WHERE id = ?", (bug_id,)).fetchone()
    return jsonify(dict(row))

@app.post("/api/bugs/<int:bug_id>/analyze")
def reanalyze_bug(bug_id):
    db = get_db()
    row = db.execute("SELECT * FROM bugs WHERE id = ?", (bug_id,)).fetchone()
    if row is None:
        return jsonify({"error": "Bug not found."}), 404
    analysis = analyze_bug(row["title"], row["description"])
    db.execute("UPDATE bugs SET ai_analysis = ? WHERE id = ?", (analysis, bug_id))
    db.commit()
    return jsonify({"analysis": analysis})

@app.delete("/api/bugs/<int:bug_id>")
def delete_bug(bug_id):
    db = get_db()
    cursor = db.execute("DELETE FROM bugs WHERE id = ?", (bug_id,))
    db.commit()
    if cursor.rowcount == 0:
        return jsonify({"error": "Bug not found."}), 404
    return jsonify({"ok": True})

init_db()

if __name__ == "__main__":
    app.run(debug=True)
