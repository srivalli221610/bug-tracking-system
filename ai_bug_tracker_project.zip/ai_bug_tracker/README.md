# BugPilot — AI-Based Bug Tracking System

A student-friendly full-stack project using Python, Flask, SQLite, HTML, CSS, JavaScript, and optional OpenAI-powered bug analysis.

## Features
- Create and store bug reports in SQLite
- Dashboard counts for total, open, in-progress, and resolved bugs
- Priority levels: Low, Medium, High, Critical
- Change bug status and delete reports
- AI-assisted analysis with suggested investigation steps
- Works without an AI key using a basic rule-based fallback

## Requirements
- Python 3.10 or later recommended
- Internet connection only if you want model-powered AI analysis

## Setup on Windows (PowerShell)

1. Extract this project folder.
2. Open PowerShell inside the `ai_bug_tracker` folder.
3. Create a virtual environment and install dependencies:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
```

4. Start the app:

```powershell
python app.py
```

5. Open this address in your browser:

`http://127.0.0.1:5000`

The SQLite database file `bugs.db` is created automatically.

## Enable model-powered AI (optional)

Without an API key, the app uses a simple rule-based analysis helper. To enable model-powered analysis, set your API key in the current PowerShell session:

```powershell
$env:OPENAI_API_KEY="your_api_key_here"
$env:OPENAI_MODEL="gpt-5.5"
python app.py
```

Use your own API key from the provider's official platform. API usage may cost money. Never put a secret API key in JavaScript, HTML, a public repository, or a screenshot. Restart the Flask app after setting the environment variable.

## Project structure

```text
ai_bug_tracker/
├── app.py
├── requirements.txt
├── README.md
├── .env.example
├── bugs.db             # created automatically at runtime
├── templates/
│   └── index.html
└── static/
    ├── style.css
    └── app.js
```

## Important
This is a local educational prototype, not a production-ready multi-user service. Before deployment, add authentication, CSRF protections, rate limiting, production server configuration, and appropriate data-access controls. AI output is only a suggestion and must be verified.
